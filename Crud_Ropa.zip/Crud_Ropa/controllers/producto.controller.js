const Producto = require('../models/producto')

exports.getProductos = async (req, res) => {
  try {
    const productos = await Producto.find()
    res.status(200).json(productos)
  } catch (error) {
    res.status(500).json({ mensaje: error.message })
  }
}

exports.getProductoById = async (req, res) => {
  try {
    const producto = await Producto.findById(req.params.id)
    if (!producto) return res.status(404).json({ mensaje: 'Producto no encontrado' })
    res.status(200).json(producto)
  } catch (error) {
    res.status(500).json({ mensaje: error.message })
  }
}

exports.createProducto = async (req, res) => {
  try {
    const producto = new Producto(req.body)
    await producto.save()
    res.status(201).json(producto)
  } catch (error) {
    res.status(400).json({ mensaje: error.message })
  }
}

exports.updateProducto = async (req, res) => {
  try {
    const producto = await Producto.findByIdAndUpdate(req.params.id, req.body, { new: true })
    if (!producto) return res.status(404).json({ mensaje: 'Producto no encontrado' })
    res.status(200).json(producto)
  } catch (error) {
    res.status(400).json({ mensaje: error.message })
  }
}

exports.deleteProducto = async (req, res) => {
  try {
    const producto = await Producto.findByIdAndDelete(req.params.id)
    if (!producto) return res.status(404).json({ mensaje: 'Producto no encontrado' })
    res.status(200).json({ mensaje: 'Producto eliminado' })
  } catch (error) {
    res.status(500).json({ mensaje: error.message })
  }
}
