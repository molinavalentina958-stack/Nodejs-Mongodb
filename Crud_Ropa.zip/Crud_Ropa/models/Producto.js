const mongoose = require('mongoose')

const productoSchema = new mongoose.Schema({
  nombre:      { type: String, required: true },
  descripcion: { type: String, required: true },
  precio:      { type: Number, required: true, min: 0 },
  talla:       { type: String, enum: ['XS','S','M','L','XL','XXL'] },
  color:       { type: String },
  stock:       { type: Number, default: 0, min: 0 },
  categoria:   { type: String, enum: ['camiseta','pantalon','vestido','accesorio'] },
  disponible:  { type: Boolean, default: true }
}, { timestamps: true })

module.exports = mongoose.model('Producto', productoSchema)
